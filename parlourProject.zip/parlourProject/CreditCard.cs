﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace parlourProject
{
    public partial class CreditCard : Form
    {

        SqlConnection con = new SqlConnection("Data Source=DESKTOP-9RPGB6G\\SQLEXPRESS;Initial Catalog=Parlour;Integrated Security=True");
        public CreditCard()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox3.Text != "" && textBox2.Text != "" && textBox4.Text != "")
            {
                string query = "insert into Payment (AccountNo,ReferenceNo,TotalAmount) Values (@accountNo,@referenceNo,@totalAmount)";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                cmd.Parameters.AddWithValue("@accountNo", textBox3.Text);
                cmd.Parameters.AddWithValue("@referenceNo", textBox2.Text);
                cmd.Parameters.AddWithValue("@totalAmount", textBox4.Text);

                cmd.ExecuteNonQuery();
                con.Close();




            }

            string cardNumber = textBox3.Text;
            string cardHolder = textBox2.Text;
            string expirationDate = dateTimePicker1.Text;
            string cvv = textBox1.Text;
            decimal amount = decimal.Parse(textBox4.Text);
           bool paymentSuccess = ProcessPayment(cardNumber, cardHolder, expirationDate, cvv, amount);

            if (paymentSuccess)
            {
                MessageBox.Show("Payment successful!");
            }
            else
            {
                MessageBox.Show("Payment failed. Please check your payment details and try again.");
            }
        }

        
        private bool ProcessPayment(string cardNumber, string cardHolder, string expirationDate, string cvv, decimal amount)
        {
           
            return true;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime sdate = dateTimePicker1.Value;
            DateTime today = DateTime.Today;


            if (dateTimePicker1.Value < DateTime.Today)
            {
                this.Focus();
                errorProvider1.Icon = Properties.Resources.error;
                errorProvider1.SetError(this.dateTimePicker1, "You Can't Select Previous Date");

            }
            else
            {
                errorProvider1.Icon = Properties.Resources.check;

            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_MouseLeave(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void CreditCard_Leave(object sender, EventArgs e)
        {

        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                this.Focus();
                errorProvider4.Icon = Properties.Resources.error;
                errorProvider4.SetError(this.textBox1, "Enter Ccv Code");

            }
            else
            {
                errorProvider4.Icon = Properties.Resources.check;

            }
        }

        private void textBox3_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox3.Text))
            {
                this.Focus();
                errorProvider2.Icon = Properties.Resources.error;
                errorProvider2.SetError(this.textBox3, "Enter your Card Number");

            }
            else
            {
                errorProvider2.Icon = Properties.Resources.check;

            }
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox2.Text))
            {
                this.Focus();
                errorProvider3.Icon = Properties.Resources.error;
                errorProvider3.SetError(this.textBox3, "Enter  Card Holder Number");

            }
            else
            {
                errorProvider3.Icon = Properties.Resources.check;

            }
        }

        private void dateTimePicker1_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(dateTimePicker1.Text))
            {
                this.Focus();
                errorProvider4.Icon = Properties.Resources.error;
                errorProvider4.SetError(this.dateTimePicker1, " Select Expairy Date");

            }
            else
            {
                errorProvider4.Icon = Properties.Resources.check;

            }
        }

        private void textBox4_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox4.Text))
            {
                this.Focus();
                errorProvider5.Icon = Properties.Resources.error;
                errorProvider5.SetError(this.textBox4, " Enter Amount Please");

            }
            else
            {
                errorProvider5.Icon = Properties.Resources.check;

            }
        }
    }
}
        