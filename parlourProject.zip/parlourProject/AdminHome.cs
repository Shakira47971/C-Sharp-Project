﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace parlourProject
{
    public partial class AdminHome : Form
    {
        public AdminHome()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void AdminHome_Load(object sender, EventArgs e)
        {
        }
        private Form currentProfileForm;

        private void ShowProfileForm(Form profileForm)
        {
            if (currentProfileForm != null)
            {
                currentProfileForm.Close();
            }

            currentProfileForm = profileForm;
            profileForm.TopLevel = false;
            profileForm.FormBorderStyle = FormBorderStyle.None;
            profileForm.Dock = DockStyle.Fill;
            panel2.Controls.Add(profileForm);
            panel2.Tag = profileForm;
            profileForm.BringToFront();
            profileForm.Show();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {


        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void label2_MouseHover(object sender, EventArgs e)
        {

        }
        private void label2_MouseLeave(object sender, EventArgs e)
        {


        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flowLayoutPanel1_MouseHover(object sender, EventArgs e)
        {
            flowLayoutPanel1.BackColor = Color.SteelBlue;
        }

        private void flowLayoutPanel1_MouseLeave(object sender, EventArgs e)
        {
            flowLayoutPanel1.BackColor = Color.Black;
        }

        private void flowLayoutPanel1_Click(object sender, EventArgs e)
        {
            ShowProfileForm(new Employee());
        }

        private void flowLayoutPanel2_Click(object sender, EventArgs e)
        {
            ShowProfileForm(new Customer());
        }

        private void flowLayoutPanel2_MouseHover(object sender, EventArgs e)
        {
            flowLayoutPanel2.BackColor = Color.Teal;

        }

        private void flowLayoutPanel2_MouseLeave(object sender, EventArgs e)
        {
            flowLayoutPanel2.BackColor = Color.Black;
        }

        private void flowLayoutPanel4_MouseHover(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel4_MouseLeave(object sender, EventArgs e)
        {


        }

        private void flowLayoutPanel4_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel3_MouseHover(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel3_MouseLeave(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flowLayoutPanel3_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel3_MouseHover_1(object sender, EventArgs e)
        {
            flowLayoutPanel3.BackColor = Color.Maroon;
        }

        private void flowLayoutPanel3_MouseLeave_1(object sender, EventArgs e)
        {
            flowLayoutPanel3.BackColor = Color.Black;

        }

        private void flowLayoutPanel4_MouseHover_1(object sender, EventArgs e)
        {
            flowLayoutPanel4.BackColor = Color.SeaGreen;
        }

        private void flowLayoutPanel4_MouseLeave_1(object sender, EventArgs e)
        {
            flowLayoutPanel4.BackColor = Color.Black;
        }

        private void flowLayoutPanel3_Click_1(object sender, EventArgs e)
        {
            ShowProfileForm(new CustomerHome());
        }

        private void flowLayoutPanel4_Click_1(object sender, EventArgs e)
        {
            ShowProfileForm(new UpdateService());
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel5_Paint(object sender, PaintEventArgs e)
        {

        }
            private void flowLayoutPanel5_Click(object sender, EventArgs e)
            {
                ShowProfileForm(new AdminLogOut());
            }

        private void pictureBox13_Click(object sender, EventArgs e)
        {

            this.Hide();
            new Login().Show();

        }
    }

    }
    
    


