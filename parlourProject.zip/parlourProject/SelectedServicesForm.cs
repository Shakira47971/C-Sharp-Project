﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Lifetime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace parlourProject
{
    public partial class SelectedServicesForm : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-9RPGB6G\\SQLEXPRESS;Initial Catalog=Parlour;Integrated Security=True");
        public SelectedServicesForm()
        {
            InitializeComponent();
            BindGridView();

        }
        void BindGridView()
        {


            string query = "select * from SelectedService";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);

            DataTable data = new DataTable();
            sda.Fill(data);
            dataGridView1.DataSource = data;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.RowTemplate.Height = 30;
        }









        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void SelectedServicesForm_Load(object sender, EventArgs e)
        {
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM SelectedService", con);

            DataTable data = new DataTable();
            sda.Fill(data);
            dataGridView1.DataSource = data;
        }
        void ResetControl()
        {
            textBox7.Clear();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String query = "Delete from SelectedService where ServiceCode=@servicecode";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@servicecode", textBox7.Text);
            con.Open();
            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Service  is removed.Choose Another Service ");
                BindGridView();
                ResetControl();


            }
            else
            {
                MessageBox.Show(" Service  is  Not removed");
            }
            con.Close();

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }


        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {

        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button2_Click_2(object sender, EventArgs e)
        {


        }

        private void button2_Click_3(object sender, EventArgs e)
        {
            decimal sum = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                DataGridViewCell cell = dataGridView1.Rows[i].Cells["Price(Tk)"];
                if (cell != null && cell.Value != null && decimal.TryParse(cell.Value.ToString(), out decimal numericValue))
                {
                    sum += numericValue;
                }
            }

            textBox1.Text = sum.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            decimal sum = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                object cellValue = dataGridView1.Rows[i].Cells["Price(Tk)"].Value;
                if (cellValue != null && cellValue != DBNull.Value && decimal.TryParse(cellValue.ToString(), out decimal numericValue))
                {
                    sum += numericValue;
                }
            }

            decimal discount = 0.4M;
            decimal discountedPrice = sum - (sum * discount);

            textBox2.Text = discountedPrice.ToString("0.00");
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }   



       