﻿using iTextSharp.text.pdf;
using iTextSharp.text;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using iTextSharp.text.pdf.qrcode;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;
using System.Data.SqlClient;



namespace parlourProject
{
    public partial class Invoice : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-9RPGB6G\\SQLEXPRESS;Initial Catalog=Parlour;Integrated Security=True");
        public Invoice()
        {
            InitializeComponent();
            comboBox1.Items.Add("Bikash");
            comboBox1.Items.Add("Nogod");
            comboBox1.Items.Add("Credit Card");
            saveFileDialog1.Filter = "PDF files (*.pdf)|*.pdf";
            saveFileDialog1.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            saveFileDialog1.FileName = "invoice_receipt.pdf";
            saveFileDialog1.Title = "Save PDF Invoice";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != -1)
            {
                string selectedValue = comboBox1.SelectedItem.ToString();
                MessageBox.Show("select method: " + selectedValue);
            }
            else
            {
                MessageBox.Show("Please select a Payment Method.");
            }
        }









        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {



            if (textBox3.Text != "" && textBox1.Text != "" && textBox2.Text != "")
            {
                string query1 = "SELECT * FROM Payment WHERE AccountNo=@accountNo AND ReferenceNo=@referenceNo AND TotalAmount=@totalAmount";

                using (SqlConnection connection1 = new SqlConnection("Data Source=DESKTOP-9RPGB6G\\SQLEXPRESS;Initial Catalog=Parlour;Integrated Security=True"))
                {
                    connection1.Open();

                    using (SqlCommand cmd1 = new SqlCommand(query1, connection1))
                    {
                        cmd1.Parameters.AddWithValue("@accountNo", textBox3.Text);
                        cmd1.Parameters.AddWithValue("@referenceNo", textBox1.Text);
                        cmd1.Parameters.AddWithValue("@totalAmount", textBox2.Text);

                        if (comboBox1.Text != "" && dateTimePicker1.Text != "")
                        {
                            string query = "SELECT * FROM Appoint WHERE Date=@date AND  Time=@time";
                            using (SqlConnection connection2 = new SqlConnection("Data Source=DESKTOP-9RPGB6G\\SQLEXPRESS;Initial Catalog=Parlour;Integrated Security=True"))
                            {
                                connection2.Open();

                                using (SqlCommand cmd2 = new SqlCommand(query, connection2))
                                {
                                    cmd2.Parameters.AddWithValue("@date", dateTimePicker1.Text);
                                    cmd2.Parameters.AddWithValue("@time", comboBox2.Text);


                                    SqlDataReader dr1 = cmd1.ExecuteReader();
                                    SqlDataReader dr = cmd2.ExecuteReader();
                                    if (dr.HasRows)
                                    {
                                        MessageBox.Show("PDF invoice generated  successfully!");

                                    }
                                    else
                                    {
                                        MessageBox.Show("Your Payment Failed!");


                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Invoice_Load(object sender, EventArgs e)
        {
            SqlDataAdapter sda1 = new SqlDataAdapter("SELECT * FROM SelectedService ", con);
            SqlDataAdapter sda2 = new SqlDataAdapter("SELECT * FROM SelectedStaff", con);

            DataTable data1 = new DataTable();
            sda1.Fill(data1);
            DataTable data2 = new DataTable();
            sda2.Fill(data2);

            dataGridView1.DataSource = data1;
            dataGridView2.DataSource = data2;
            dataGridView1.RowTemplate.Height = 30;
            dataGridView2.RowTemplate.Height = 30;




        }





        private void button2_Click(object sender, EventArgs e)
        {


            if (textBox3.Text != "" && textBox1.Text != "" && textBox2.Text != "")
            {
                DateTime selectedDate = dateTimePicker1.Value;
                DateTime today = DateTime.Today;

                if (selectedDate < today)
                {
                    MessageBox.Show("You can't select a previous date for the appointment.", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    string outputPath = saveFileDialog1.FileName;
                    using (FileStream stream = new FileStream(outputPath, FileMode.Create))
                    {

                        Document pdfdoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
                        PdfWriter writer = PdfWriter.GetInstance(pdfdoc, stream);
                        pdfdoc.Open();
                        pdfdoc.Add(new Paragraph("                                                                         Beauty Verse                                              "));
                        pdfdoc.Add(new Paragraph("======================================================================================"));
                        pdfdoc.Add(new Paragraph("                                                                   Invoice Record For Customer                                     "));
                        pdfdoc.Add(new Paragraph("======================================================================================"));


                        Paragraph content1 = new Paragraph("Account No: " + textBox3.Text);
                        Paragraph content2 = new Paragraph("Reference No: " + textBox1.Text);
                        decimal total = Convert.ToDecimal(textBox2.Text);
                        Paragraph totalAmount = new Paragraph("Paid Amount" + total.ToString("0.00"));
                        Paragraph content3 = new Paragraph("Paid Amount(Tk): " + textBox2.Text);
                        Paragraph content4 = new Paragraph("Pay By: " + comboBox1.SelectedItem.ToString());


                        pdfdoc.Add(content1);
                        pdfdoc.Add(content2);
                        pdfdoc.Add(content3);
                        pdfdoc.Add(content4);



                        pdfdoc.Add(new Paragraph("Total Price:" + textBox4.Text));
                        pdfdoc.Add(new Paragraph("After Discounte Total  Price is:" + textBox5.Text));
                        pdfdoc.Add(new Paragraph("Appointment Date:" + dateTimePicker1.Value));
                        pdfdoc.Add(new Paragraph("Appointment Time:" + comboBox2.SelectedItem.ToString()));
                        pdfdoc.Add(new Paragraph("======================================================================================"));
                        pdfdoc.Add(new Paragraph("                                                                      Selected Service                                                 "));

                        pdfdoc.Add(new Paragraph("======================================================================================"));

                        exportgridtopdf(dataGridView1, pdfdoc, "text");
                        pdfdoc.Add(new Paragraph("======================================================================================"));
                        pdfdoc.Add(new Paragraph("                                                                       Selected Staff                                        "));

                        pdfdoc.Add(new Paragraph("======================================================================================"));
                        exportgridtopdf(dataGridView2, pdfdoc, "text");


                        pdfdoc.Close();
                        stream.Close();

                        MessageBox.Show("PDF invoice saved   successfully!");
                    }
                }
            }
            else
            {
                MessageBox.Show("Your Payment Failed");
            }
        }






        private void exportgridtopdf(DataGridView dataGridView1, Document pdfdoc, string filename)
        {
            BaseFont bf = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1250, BaseFont.EMBEDDED);
            PdfPTable pdftable = new PdfPTable(dataGridView1.Columns.Count);
            pdftable.DefaultCell.Padding = 3;
            pdftable.WidthPercentage = 100;
            pdftable.HorizontalAlignment = Element.ALIGN_LEFT;
            pdftable.DefaultCell.BorderWidth = 1;

            iTextSharp.text.Font text = new iTextSharp.text.Font(bf, 10, iTextSharp.text.Font.NORMAL);

            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                PdfPCell headerCell = new PdfPCell(new Phrase(column.HeaderText, text));
                headerCell.BackgroundColor = new iTextSharp.text.BaseColor(240, 240, 240);
                pdftable.AddCell(headerCell);
            }

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell.Value != null)
                    {
                        pdftable.AddCell(new Phrase(cell.Value.ToString(), text));
                    }
                    else
                    {
                        pdftable.AddCell(new Phrase("", text));
                    }
                }
            }


            pdfdoc.Add(pdftable);
        }

        private void exportgridtopdf2(DataGridView dataGridView2, Document pdfdoc, string filename)
        {
            BaseFont bf = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1250, BaseFont.EMBEDDED);
            PdfPTable pdftable = new PdfPTable(dataGridView1.Columns.Count);
            pdftable.DefaultCell.Padding = 3;
            pdftable.WidthPercentage = 100;
            pdftable.HorizontalAlignment = Element.ALIGN_LEFT;
            pdftable.DefaultCell.BorderWidth = 1;

            iTextSharp.text.Font text = new iTextSharp.text.Font(bf, 10, iTextSharp.text.Font.NORMAL);

            foreach (DataGridViewColumn column in dataGridView2.Columns)
            {
                PdfPCell headerCell = new PdfPCell(new Phrase(column.HeaderText, text));
                headerCell.BackgroundColor = new iTextSharp.text.BaseColor(240, 240, 240);
                pdftable.AddCell(headerCell);
            }

            foreach (DataGridViewRow row in dataGridView2.Rows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell.Value != null)
                    {
                        pdftable.AddCell(new Phrase(cell.Value.ToString(), text));
                    }
                    else
                    {
                        pdftable.AddCell(new Phrase("", text));
                    }
                }
            }


            pdfdoc.Add(pdftable);
        }





        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            decimal sum = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                DataGridViewCell cell = dataGridView1.Rows[i].Cells["Price(Tk)"];
                if (cell != null && cell.Value != null && decimal.TryParse(cell.Value.ToString(), out decimal numericValue))
                {
                    sum += numericValue;
                }
            }

            textBox4.Text = sum.ToString();
        }
    

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            decimal sum = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                object cellValue = dataGridView1.Rows[i].Cells["Price(Tk)"].Value;
                if (cellValue != null && cellValue != DBNull.Value && decimal.TryParse(cellValue.ToString(), out decimal numericValue))
                {
                    sum += numericValue;
                }
            }

            decimal discount = 0.4M;
            decimal discountedPrice = sum - (sum * discount);

            textBox5.Text = discountedPrice.ToString("0.00");
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime sdate = dateTimePicker1.Value;
            DateTime today = DateTime.Today;
            if(dateTimePicker1.Value < DateTime.Today)
            {
                this.Focus();
                errorProvider1.Icon = Properties.Resources.error;
                errorProvider1.SetError(this.dateTimePicker1, "You Can't Select Previous Date");

            }
            else
            {
                errorProvider1.Icon = Properties.Resources.check;

            }
        }

    


    

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

   

    
   




