﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace parlourProject
{
    public partial class SelectedStaff : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-9RPGB6G\\SQLEXPRESS;Initial Catalog=Parlour;Integrated Security=True");
        public SelectedStaff()
        {
            InitializeComponent();
           
            BindGridView();
        }
        void BindGridView()
        {


            string query = "select * from SelectedStaff";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);

            DataTable data = new DataTable();
            sda.Fill(data);
            dataGridView1.DataSource = data;



            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridView1.RowTemplate.Height = 30;
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        void ResetControl()
        {
            textBox2.Clear();

        }


        private void button3_Click(object sender, EventArgs e)
        {
            String query = "Delete from SelectedStaff where StaffId=@staffid";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@staffid", textBox2.Text);
            con.Open();
            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("  Staff is removed .Choose Another Staff ");
                BindGridView();
                ResetControl();


            }
            else
            {
                MessageBox.Show("Staff  is  Not removed");
            }
            con.Close();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void SelectedStaff_Load(object sender, EventArgs e)
        {
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM SelectedStaff", con);

            DataTable data = new DataTable();
            sda.Fill(data);
            dataGridView1.DataSource = data;
        }
       

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
             
        }
    }
}
