﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace parlourProject
{
    public partial class LogOut : Form
    {
        private BackgroundWorker dataLoader;
        public LogOut()
        {
            InitializeComponent();
            dataLoader = new BackgroundWorker();
            dataLoader.DoWork += DataLoader_DoWork;
            dataLoader.ProgressChanged += DataLoader_ProgressChanged;
            dataLoader.RunWorkerCompleted += DataLoader_RunWorkerCompleted;
            dataLoader.WorkerReportsProgress = true;

            MaroonProgressBar maroonProgressBar = new MaroonProgressBar();
            maroonProgressBar.Dock = DockStyle.Top;


            Controls.Add(maroonProgressBar);
        }
       

        private void DataLoader_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {



            progressBar1.Value = e.ProgressPercentage;

        }
        private void DataLoader_DoWork(object sender, DoWorkEventArgs e)
        {

            for (int i = 0; i <= 100; i++)
            {

                Thread.Sleep(50);


                dataLoader.ReportProgress(i);
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;

            dataLoader.RunWorkerAsync();

            this.Refresh();
           
        }
        private void DataLoader_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            panel1.Visible = false;


        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void LogOut_Load(object sender, EventArgs e)
        {

        }
    }

}
