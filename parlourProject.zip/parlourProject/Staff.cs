﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace parlourProject
{
    public partial class Staff : Form
    {
        
        public Staff()
        {
            InitializeComponent();
           



        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-9RPGB6G\\SQLEXPRESS;Initial Catalog=Parlour;Integrated Security=True");


        private void button5_Click(object sender, EventArgs e)
        {
            string categoryToSearch = comboBox1.Text;
           



            string query = "SELECT  StaffId,StaffName, StaffCatagory,ScheduleTime, Rating FROM Employee WHERE StaffCatagory LIKE @staffcategoryToSearch ";
            SqlCommand cmd = new SqlCommand(query, con);
           
            cmd.Parameters.AddWithValue("@staffcategoryToSearch", "%" + categoryToSearch + "%");
            

            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.HasRows)
            {
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);

                dataGridView1.DataSource = dataTable;
            }
            else
            {
                MessageBox.Show($"No Staff Found for '{categoryToSearch}' .", "Staff is not Found");
            }

            reader.Close();
            con.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private Image GetPhoto(byte[] photo)
        {
            MemoryStream ms = new MemoryStream(photo);
            return Image.FromStream(ms);
        }

        private List<DataGridViewRow> selectedRows = new List<DataGridViewRow>();
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if(dataGridView1.SelectedRows.Count > 0)
                {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                selectedRows.Add(selectedRow);
                Image selectedRatingImage = GetPhoto((byte[])selectedRow.Cells[2].Value);

                
               


            }
        }


        private void Staff_Load(object sender, EventArgs e)
        {
            SqlDataAdapter sda = new SqlDataAdapter("SELECT StaffId, StaffCatagory,StaffName,ScheduleTime, Rating FROM Employee", con);

            DataTable data = new DataTable();
            sda.Fill(data);
            dataGridView1.DataSource = data;
            DataGridViewCheckBoxColumn checkboxColumn = new DataGridViewCheckBoxColumn();
            checkboxColumn.HeaderText = "Select";
            checkboxColumn.Name = "Check1boxColumn";
            dataGridView1.Columns.Insert(0, checkboxColumn);

            dataGridView1.Columns.Remove("Rating");




            DataGridViewImageColumn imageColumn = new DataGridViewImageColumn();
            imageColumn.DataPropertyName = "Rating"; 
            imageColumn.HeaderText = "Rating"; 
            imageColumn.ImageLayout = DataGridViewImageCellLayout.Stretch;
            dataGridView1.Columns.Add(imageColumn);
        }

        

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
           
           
           
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
       
       

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int inserted = 0;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                bool isSelected = Convert.ToBoolean(row.Cells["check1BoxColumn"].Value);
                if (isSelected)
                {
                    string Constring = "Data Source=DESKTOP-9RPGB6G\\SQLEXPRESS;Initial Catalog=Parlour;Integrated Security=True";
                    using (SqlConnection con = new SqlConnection(Constring))

                    {
                        using (SqlCommand cmd = new SqlCommand("Insert into SelectedStaff(StaffId,StaffName,StaffCatagory,ScheduleTime) values(@staffid,@staffname, @staffcatagory,@scheduleTime)", con))
                        {
                            cmd.Parameters.AddWithValue("@staffid", row.Cells["StaffId"].Value);
                            cmd.Parameters.AddWithValue("@staffname", row.Cells["StaffName"].Value);
                            cmd.Parameters.AddWithValue("@staffcatagory", row.Cells["StaffCatagory"].Value);
                            cmd.Parameters.AddWithValue("@scheduleTime", row.Cells["ScheduleTime"].Value);
                               


                            con.Open();
                            cmd.ExecuteNonQuery();
                            con.Close();

                        }

                    }
                    inserted++;
                }
            }
            if (inserted > 0)
            {
                MessageBox.Show(string.Format("{0} records inserted", inserted), "Message");

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
           

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
   
