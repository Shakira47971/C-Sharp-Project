﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace parlourProject
{
    public partial class Nogod : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-9RPGB6G\\SQLEXPRESS;Initial Catalog=Parlour;Integrated Security=True");
        private BackgroundWorker dataLoader;
        public Nogod()
        {
            InitializeComponent();
            dataLoader = new BackgroundWorker();
            dataLoader.DoWork += DataLoader_DoWork;
            dataLoader.ProgressChanged += DataLoader_ProgressChanged;
            dataLoader.RunWorkerCompleted += DataLoader_RunWorkerCompleted;
            dataLoader.WorkerReportsProgress = true;

            MaroonProgressBar maroonProgressBar = new MaroonProgressBar();
            maroonProgressBar.Dock = DockStyle.Top;


            Controls.Add(maroonProgressBar);
        }
        private void DataLoader_DoWork(object sender, DoWorkEventArgs e)
        {

            for (int i = 0; i <= 100; i++)
            {

                Thread.Sleep(50);


                dataLoader.ReportProgress(i);
            }
        }
        private void DataLoader_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {



            progressBar1.Value = e.ProgressPercentage;

        }
        private void DataLoader_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {

            panel3.Visible = false;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            panel3.Visible = true;

            dataLoader.RunWorkerAsync();

            this.Refresh();
            if (textBox3.Text != "" && textBox1.Text != "" && textBox2.Text != "")
            {
                string query = "insert into Payment (AccountNo,ReferenceNo,TotalAmount) Values (@accountNo,@referenceNo,@totalAmount)";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                cmd.Parameters.AddWithValue("@accountNo", textBox3.Text);
                cmd.Parameters.AddWithValue("@referenceNo", textBox1.Text);
                cmd.Parameters.AddWithValue("@totalAmount", textBox2.Text);

                cmd.ExecuteNonQuery();
                con.Close();




            }


        }
            private bool ProcessPayment(string cardNumber, decimal amount, string cardHolder, string count, string cvv)
            {

                return true;
            }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_MouseLeave(object sender, EventArgs e)
        {

        }

        private void textBox3_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox3.Text))
            {
                this.Focus();
                errorProvider1.Icon = Properties.Resources.error;
                errorProvider1.SetError(this.textBox3, "Enter your Merchant Account Number");

            }
            else
            {
                errorProvider1.Icon = Properties.Resources.check;

            }
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox2.Text))
            {
                this.Focus();
                errorProvider2.Icon = Properties.Resources.error;
                errorProvider2.SetError(this.textBox2, "Enter  Amount Please!");

            }
            else
            {
                errorProvider2.Icon = Properties.Resources.check;

            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                this.Focus();
                errorProvider3.Icon = Properties.Resources.error;
                errorProvider3.SetError(this.textBox1, "Enter Reference Number");

            }
            else
            {
                errorProvider3.Icon = Properties.Resources.check;

            }
        }

        private void textBox4_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox4.Text))
            {
                this.Focus();
                errorProvider4.Icon = Properties.Resources.error;
                errorProvider4.SetError(this.textBox4, "Enter Counter Number");

            }
            else
            {
                errorProvider4.Icon = Properties.Resources.check;

            }
        }

        private void textBox5_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox5.Text))
            {
                this.Focus();
                errorProvider5.Icon = Properties.Resources.error;
                errorProvider5.SetError(this.textBox5, "Enter pin Number");

            }
            else
            {
                errorProvider5.Icon = Properties.Resources.check;

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string cardNumber = textBox3.Text;
            decimal amount = decimal.Parse(textBox2.Text);
            string cardHolder = textBox1.Text;
            string count = textBox4.Text;
            string cvv = textBox5.Text;

            bool paymentSuccess = ProcessPayment(cardNumber, amount, cardHolder, count, cvv);


            if (paymentSuccess)
            {
                MessageBox.Show(" Payment successful!");
            }
            else
            {
                MessageBox.Show("Payment failed. Please check your payment details and try again.");
            }

        }
    }
    }

