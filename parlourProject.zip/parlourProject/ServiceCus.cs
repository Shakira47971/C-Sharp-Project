﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Threading;
using System.Security.Cryptography;
using System.Windows.Forms;
using parlourProject;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Drawing;
using System.Data.Common;
using System.Reflection.Emit;
using System.Runtime.Remoting.Lifetime;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using System.Collections;
using System.IO;

namespace parlourProject
{


    public partial class ServiceCus : Form
    {

        private List<string> selectedServices = new List<string>();

        SqlConnection con = new SqlConnection("Data Source=DESKTOP-9RPGB6G\\SQLEXPRESS;Initial Catalog=Parlour;Integrated Security=True");
        public ServiceCus()
        {

            InitializeComponent();



        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {





        }
        private void dataGridView1_CellContentClick_2(object sender, DataGridViewCellEventArgs e)
        {




        }





        private void button5_Click(object sender, EventArgs e)
        {

            string categoryToSearch = comboBox1.Text;
            int GivenPrice;



            string query = "SELECT  ServiceCode,ServiceCatagory,ServiceName, [Price(Tk)],Picture FROM UpdateService WHERE ServiceCatagory LIKE @servicecategoryToSearch AND  [Price(Tk)] <= @GivenPrice";
            SqlCommand cmd = new SqlCommand(query, con);
            if (!int.TryParse(textBox7.Text, out GivenPrice))
            {
                MessageBox.Show("Please enter a valid numeric value for the customer's price.", "Input Error");
                return;
            }

            cmd.Parameters.AddWithValue("@servicecategoryToSearch", "%" + categoryToSearch + "%");
            cmd.Parameters.AddWithValue("@GivenPrice", GivenPrice);


            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.HasRows)
            {
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);

                dataGridView1.DataSource = dataTable;
            }
            else
            {
                MessageBox.Show($"No Services Found for '{categoryToSearch}' within the specified price range.", "Service Not Found");
            }

            reader.Close();
            con.Close();
        }


        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }


        private void FacialCus_Load(object sender, EventArgs e)
        {
            SqlDataAdapter sda = new SqlDataAdapter("select * from UpdateService", con);

            DataTable data = new DataTable();
            sda.Fill(data);
            dataGridView1.DataSource = data;
            DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
            checkBoxColumn.HeaderText = "Select";
            checkBoxColumn.Width = 50;
            checkBoxColumn.Name = "check1BoxColumn";
            dataGridView1.Columns.Insert(0, checkBoxColumn);


            
            dataGridView1.RowTemplate.Height = 80;



        }
        private Image GetPhoto(byte[] photo)
        {
            MemoryStream ms = new MemoryStream(photo);
            return Image.FromStream(ms);
        }
        private List<DataGridViewRow> selectedRows = new List<DataGridViewRow>();



        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
               
        Image selectedRatingImage = GetPhoto((byte[])selectedRow.Cells[2].Value);


    }
}



            
        
      

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }




        private void panel3_DragDrop(object sender, DragEventArgs e)
        {
        }
        private void panel3_Paint(object sender, PaintEventArgs e)
        {
        }
        private void progressBar1_Click(object sender, EventArgs e)
        {
        }

        private void progressBar1_Layout(object sender, LayoutEventArgs e)
        {

        }



       






        private void panel3_Click(object sender, EventArgs e)
        {


        }

        private void progressBar1_Click_1(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {



          




        }
        private void dataGridView1_Click(object sender, EventArgs e)
        {


        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


        }


        private void button2_Click(object sender, EventArgs e)
        {





        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            int inserted = 0;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                bool isSelected = Convert.ToBoolean(row.Cells["check1BoxColumn"].Value);
                if (isSelected)
                {
                    string Constring = "Data Source=DESKTOP-9RPGB6G\\SQLEXPRESS;Initial Catalog=Parlour;Integrated Security=True";
                    using (SqlConnection con = new SqlConnection(Constring))

                    {
                        using (SqlCommand cmd = new SqlCommand("Insert into SelectedService(ServiceCode,ServiceCatagory,ServiceName,[Price(Tk)]) values(@servicecode, @servicecatagory, @servicename, @price)", con))
                        {

                            cmd.Parameters.AddWithValue("@servicecode", row.Cells["ServiceCode"].Value);
                            cmd.Parameters.AddWithValue("@servicecatagory", row.Cells["ServiceCatagory"].Value);
                            cmd.Parameters.AddWithValue("@servicename", row.Cells["ServiceName"].Value);
                            cmd.Parameters.AddWithValue("@price", row.Cells["Price(Tk)"].Value);
                                 

                            con.Open();
                            cmd.ExecuteNonQuery();
                            con.Close();

                        }

                    }
                    inserted++;
                }
            }
            if (inserted > 0)
            {
                MessageBox.Show(string.Format("{0} records inserted", inserted), "Message");
            }

        }
       



                    
    private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
           
           

        }

        private void button2_Click_2(object sender, EventArgs e)
        {
           
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
    }

    


    
    

    
        





