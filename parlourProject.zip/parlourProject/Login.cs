﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace parlourProject
{
    public partial class Login : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-9RPGB6G\\SQLEXPRESS;Initial Catalog=Parlour;Integrated Security=True");
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                this.Focus();
                errorProvider1.Icon = Properties.Resources.error;
                errorProvider1.SetError(this.textBox1, "Enter your Email please!");

            }
            else
            {
                errorProvider1.Icon = Properties.Resources.check;

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox2.Text))
            {
                this.Focus();
                errorProvider2.Icon = Properties.Resources.error;
                errorProvider2.SetError(this.textBox2, "Enter your Password please!");

            }
            else
            {
                errorProvider2.Icon = Properties.Resources.check;

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0 && textBox1.Text == "admin567@gmail.com" && textBox2.Text == "47971")
            {
                MessageBox.Show("You Have Succesfully Log in As a Admin");
                this.Hide();
                new AdminHome().Show();


            }



           else if (comboBox1.SelectedIndex == 1&&  textBox1.Text != "" && textBox2.Text != "")
                {


                    string query = "select * from Reg where [Email] =@email and [Password] = @pass";



                    SqlCommand cmd = new SqlCommand(query, con);


                    cmd.Parameters.AddWithValue("@email", textBox1.Text);
                    cmd.Parameters.AddWithValue("@pass", textBox2.Text);

                    con.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.HasRows == true)
                    {
                    
                    MessageBox.Show("You Have Succesfully Log in As a Customer");
                    this.Hide();
                    new CustomerHome().Show();


                }
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Login Failed", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);


                }

   

               

            }
            
            private void comboBox1_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(comboBox1.Text))
            {
                this.Focus();
                errorProvider3.Icon = Properties.Resources.error;
                errorProvider3.SetError(this.comboBox1, "Select Role Please");

            }
            else
            {
                errorProvider3.Icon = Properties.Resources.check;

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Reg().Show();

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }
    }
    }

