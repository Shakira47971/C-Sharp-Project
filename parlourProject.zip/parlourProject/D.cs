﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace parlourProject
{
    public partial class D : Form
    {
        private int currentRating = 0;
        public D()
        {
            InitializeComponent();
            InitializeStarRating();
        }

        private void D_Load(object sender, EventArgs e)
        {
        }
        private void InitializeStarRating()
        {
            
            for (int i = 1; i <= 5; i++)
            {
                PictureBox star = new PictureBox
                {
                    Image = Properties.Resources.EmptyStar, // Set the empty star image
                    SizeMode = PictureBoxSizeMode.Zoom,
                    Tag = i // Store the star index
                };
                star.MouseEnter += Star_MouseEnter;
                star.MouseLeave += Star_MouseLeave;
                star.MouseClick += Star_MouseClick;

                panel1.Controls.Add(star);
            }
        }
        private void Star_MouseEnter(object sender, EventArgs e)
        {
            PictureBox star = (PictureBox)sender;
            int starIndex = (int)star.Tag;

            // Update star appearance based on cursor position
            for (int i = 1; i <= 5; i++)
            {
                if (i <= starIndex)
                    panel1.Controls[i - 1].BackgroundImage = Properties.Resources.FullStar;
                else
                    panel1.Controls[i - 1].BackgroundImage = Properties.Resources.EmptyStar;
            }
        }
        private void Star_MouseLeave(object sender, EventArgs e)
        {
            // Reset star appearance to reflect current rating
            UpdateStarAppearance();
        }
        private void Star_MouseClick(object sender, MouseEventArgs e)
        {
            PictureBox clickedStar = (PictureBox)sender;
            currentRating = (int)clickedStar.Tag;

            // Update star appearance and perform any other actions
            UpdateStarAppearance();

            // You can perform additional actions here, like saving the rating to a database.
        }
        private void UpdateStarAppearance()
        {
            for (int i = 1; i <= 5; i++)
            {
                if (i <= currentRating)
                    panel1.Controls[i - 1].BackgroundImage = Properties.Resources.FullStar;
                else
                    panel1.Controls[i - 1].BackgroundImage = Properties.Resources.EmptyStar;
            }
        }
    }
}
    

