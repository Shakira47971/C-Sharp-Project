﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace parlourProject
{
    public partial class Appointment : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-9RPGB6G\\SQLEXPRESS;Initial Catalog=Parlour;Integrated Security=True");
        public Appointment()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime sdate = dateTimePicker1.Value;
            DateTime today = DateTime.Today;


            if (dateTimePicker1.Value < DateTime.Today)
            {
                this.Focus();
                errorProvider1.Icon = Properties.Resources.error;
                errorProvider1.SetError(this.dateTimePicker1, "You Can't Select Previous Date");

            }
            else
            {
                errorProvider1.Icon = Properties.Resources.check;

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != "" && dateTimePicker1.Text != "") { 
            string query = "insert into Appoint (Date,Time) Values (@date,@time)";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            cmd.Parameters.AddWithValue("@date", dateTimePicker1.Text);
            cmd.Parameters.AddWithValue("@time", comboBox1.Text );

            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Your Appointment is Successfull", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);


        }
            else
            {
                MessageBox.Show("Appointment  Failed", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



}

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
    }

