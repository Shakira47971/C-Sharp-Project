﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace parlourProject
{
    public partial class Customer : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-9RPGB6G\\SQLEXPRESS;Initial Catalog=BeautyVerse;Integrated Security=True");
        

        public Customer()
        {
            InitializeComponent();
            BindGridView();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            textBox9.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            textBox8.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox7.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox6.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();

            textBox1.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();

        
    }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e, object ComboBox2)
        {
        }
        void BindGridView()
        {
            string query = "SELECT * FROM Customer";

            SqlDataAdapter sda = new SqlDataAdapter(query, con);
  
                DataTable data = new DataTable();
                sda.Fill(data);
                dataGridView1.DataSource = data;
      

            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.RowTemplate.Height = 20;
        }


        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string query = "insert into Customer values (@id,@name,@contact,@email,@history)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@id", textBox9.Text);
            cmd.Parameters.AddWithValue("@name", textBox8.Text);
            cmd.Parameters.AddWithValue("@contact", textBox7.Text);
            cmd.Parameters.AddWithValue("@email", textBox6.Text);
            cmd.Parameters.AddWithValue("history",textBox1.Text);
            con.Open();
            int a = cmd.ExecuteNonQuery();

            if (a > 0)
            {
                MessageBox.Show(" Customer Data Is Added");
                BindGridView();
                ResetControl();

            }
            else
            {
                MessageBox.Show("Customer Data is Not Added");
            }
            con.Close();


        }
       
       
        private void button4_Click(object sender, EventArgs e) {
            ResetControl();
        }
        void ResetControl()
        {
            textBox9.Clear();
            textBox8.Clear();
            textBox7.Clear();
            textBox6.Clear();
            textBox1.Clear();
            


        }

            
            
        
       
       

       
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            string query = "update Customer set Id=@id,Name=@name,Contact=@contact,Email=@email,History=@history  Where Id=@id";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@id", textBox9.Text);
            cmd.Parameters.AddWithValue("@name", textBox8.Text);
            cmd.Parameters.AddWithValue("@contact", textBox7.Text);
            cmd.Parameters.AddWithValue("@email", textBox6.Text);
            cmd.Parameters.AddWithValue("@history", textBox1.Text);



            con.Open();
            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Customer Data is Edited ");
                BindGridView();
                ResetControl();


            }
            else
            {
                MessageBox.Show(" Customer Data Not Edited");
            }
            con.Close();



        }

        private void button3_Click_1(object sender, EventArgs e)
        {

            string query = "delete from Customer where Id=@id";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@id", textBox9.Text);
            con.Open();
            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show( " Customer Data Is Removed");
                BindGridView();
                ResetControl();


            }
            else
            {
                MessageBox.Show("Customer Data Is Not Removed");
            }
            con.Close();

        }

        private void Customer_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            
                

                if (!string.IsNullOrEmpty(textBox9.Text))
                {
                    string query = "SELECT * FROM Customer WHERE Id = @id";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@id", textBox9.Text);

                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.HasRows)
                    {
                        reader.Read(); 

                        MessageBox.Show("Customer Found!");
                    }
                    else
                    {
                        MessageBox.Show("Customer Not Found");
                        
                    }

                    reader.Close();
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Please enter a valid ID to search.");
                }
            }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            button1.BackColor = Color.Green;
            button1.ForeColor = Color.White;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.White;
            button1.ForeColor = Color.Green;
        }

        private void button3_MouseHover(object sender, EventArgs e)
        {
            button3.BackColor = Color.Red;
            button3.ForeColor = Color.White;
        }

        private void button3_MouseLeave(object sender, EventArgs e)
        {
            button3.BackColor = Color.White;
            button3.ForeColor = Color.Red;
        }

        private void button2_MouseHover(object sender, EventArgs e)
        {
            button2.BackColor = Color.Navy;
            button2.ForeColor = Color.White;
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            button2.BackColor = Color.White;
            button2.ForeColor = Color.Navy;
        }

        private void button4_MouseHover(object sender, EventArgs e)
        {
            button4.BackColor = Color.Purple;
            button4.ForeColor = Color.White;
        }

        private void button4_MouseLeave(object sender, EventArgs e)
        {
            button4.BackColor = Color.White;
            button4.ForeColor = Color.Purple;
        }

        private void button5_MouseHover(object sender, EventArgs e)
        {
            button5.BackColor = Color.Black;
            button5.ForeColor = Color.White;

        }

        private void button5_MouseLeave(object sender, EventArgs e)
        {

            button5.BackColor = Color.White;
            button5.ForeColor = Color.Black;
        }
    }
    }
      
    

        
    
