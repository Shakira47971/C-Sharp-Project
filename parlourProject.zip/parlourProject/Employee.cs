﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace parlourProject
{
    public partial class Employee : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-9RPGB6G\\SQLEXPRESS;Initial Catalog=Parlour;Integrated Security=True");
        public Employee()

        {

            InitializeComponent();
            BindGridView();
        }

        private void Home_Load(object sender, EventArgs e)
        {

        }
        void BindGridView()
        {
           
            string query = "select * from Employee";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);

            DataTable data = new DataTable();
            sda.Fill(data);
            dataGridView1.DataSource = data;

            DataGridViewImageColumn dgv = new DataGridViewImageColumn();
            dgv = (DataGridViewImageColumn)dataGridView1.Columns[5];
            dgv.ImageLayout = DataGridViewImageCellLayout.Stretch;

            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridView1.RowTemplate.Height = 20;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {



            textBox10.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            textBox9.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox8.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox7.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            comboBox1.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            pictureBox2.Image = GetPhoto((byte[])dataGridView1.SelectedRows[0].Cells[5].Value);

        }
           
        
        private Image GetPhoto(byte[] photo)
        {
            MemoryStream ms = new MemoryStream(photo);
            return Image.FromStream(ms);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            

                string query = "insert into Employee values (@staffid,@staffname,@salary,@scheduleTime,@staffcatagory,@rating)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@staffid", textBox10.Text);
                cmd.Parameters.AddWithValue("@staffname", textBox9.Text);
                cmd.Parameters.AddWithValue("@salary", textBox8.Text);
                cmd.Parameters.AddWithValue("@scheduleTime", textBox7.Text);
                cmd.Parameters.AddWithValue("@staffcatagory", comboBox1.Text);
                cmd.Parameters.AddWithValue("@rating", SavePhoto());

                con.Open();
                int a = cmd.ExecuteNonQuery();

                if (a > 0)
                {
                    MessageBox.Show(" Employee Data  is Added ");
                    BindGridView();
                    ResetControl();

                }
                else
                {
                    MessageBox.Show(" Employee Data is  Not Added");
                }
            con.Close();
           
            

        }

        private byte[] SavePhoto()
        {
            MemoryStream ms = new MemoryStream();
            pictureBox2.Image.Save(ms, pictureBox2.Image.RawFormat);
            return ms.GetBuffer();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ResetControl();
        }
        void ResetControl()
        {
            textBox10.Clear();
            textBox9.Clear();
            textBox8.Clear();
            textBox7.Clear();
            comboBox1.Items.Clear();

            pictureBox2.Image = Properties.Resources.no_image_avaiable;
        }

        private void button2_Click1(object sender, EventArgs e)
        {
              
                string query = "update Employee set StaffId=@staffid,StaffName=@staffname,[Salary(Tk)]=@salary,ScheduleTime=@scheduleTime, StaffCatagory=@staffcatagory,Rating=@rating where StaffId=@staffid";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@staffid", textBox10.Text);
                cmd.Parameters.AddWithValue("@staffname", textBox9.Text);
                cmd.Parameters.AddWithValue("@salary", textBox8.Text);
                cmd.Parameters.AddWithValue("@scheduleTime", textBox7.Text);
                cmd.Parameters.AddWithValue("@staffcatagory", comboBox1.Text);
                cmd.Parameters.AddWithValue("@rating", SavePhoto());
            con.Open();
            int rowsAffected = cmd.ExecuteNonQuery();
           
            if (rowsAffected > 0)
                {
                    MessageBox.Show("Employee Data is Edited ");
                BindGridView();
                ResetControl();
            

        }
                else
                {
                    MessageBox.Show(" Employee Data Not Edited");
                }
            con.Close();
            
            


        }

        private void button3_Click(object sender, EventArgs e)
        {
            

                String query = "Delete from Employee where StaffId=@staffid";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@staffid", textBox10.Text);
                con.Open();
            int rowsAffected = cmd.ExecuteNonQuery();
            
            if (rowsAffected > 0)
            {
                MessageBox.Show(" Employee Data is removed ");
                BindGridView();
                ResetControl();
           

        }
            else
            {
                MessageBox.Show(" Employee Data is  Not removed");
            }
            con.Close();
            

        }


        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Select Image";
           
            ofd.Filter = "ALL IMAGE FILE (*.*) | *.*";
           
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox2.Image = new Bitmap(ofd.FileName);
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string categoryToSearch = comboBox1.Text;
            



            string query = "SELECT  StaffId,StaffName, ScheduleTime, Rating FROM Employee WHERE StaffCatagory LIKE @staffcategoryToSearch ";
            SqlCommand cmd = new SqlCommand(query, con);
            
            cmd.Parameters.AddWithValue("@staffcategoryToSearch", "%" + categoryToSearch + "%");
           

            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.HasRows)
            {
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);

                dataGridView1.DataSource = dataTable;
            }
            else
            {
                MessageBox.Show($"No Staff Found for '{categoryToSearch}' ", "Staff is not Found");
            }

            reader.Close();
            con.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            button1.BackColor = Color.Green;
            button1.ForeColor = Color.White;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.White;
            button1.ForeColor = Color.Green;
        }

        private void button3_MouseHover(object sender, EventArgs e)
        {
            button3.BackColor = Color.Red;
            button3.ForeColor = Color.White;
        }

        private void button3_MouseLeave(object sender, EventArgs e)
        {
            button3.BackColor = Color.White;
            button3.ForeColor = Color.Red;
        }

        private void button4_MouseHover(object sender, EventArgs e)
        {
            button4.BackColor = Color.Purple;
            button4.ForeColor = Color.White;
        }

        private void button4_MouseLeave(object sender, EventArgs e)
        {
            button4.BackColor = Color.White;
            button4.ForeColor = Color.Purple;
        }

        private void button2_MouseHover(object sender, EventArgs e)
        {
            button2.BackColor = Color.Navy;
            button2.ForeColor = Color.White;
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            button2.BackColor = Color.White;
            button2.ForeColor = Color.Navy;
        }

        private void button5_MouseHover(object sender, EventArgs e)
        {
            button5.BackColor = Color.Black;
            button5.ForeColor = Color.White;
        }

        private void button5_MouseLeave(object sender, EventArgs e)
        {
            button5.BackColor = Color.White;
            button5.ForeColor = Color.Black;
        }
    }
    }
    
    
                                   


             
