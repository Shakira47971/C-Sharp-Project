﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace parlourProject
{
    public partial class Reg : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-9RPGB6G\\SQLEXPRESS;Initial Catalog=Parlour;Integrated Security=True");
        public Reg()
        {
            InitializeComponent();
        }
        private string getradio()
        {
            if (radioButton1.Checked)
            {
                return "Female";
            }

            else
            {
                return "Others";
            }

        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                this.Focus();
                errorProvider1.Icon = Properties.Resources.error;
                errorProvider1.SetError(this.textBox1, "Enter your id please!");

            }
            else
            {
                errorProvider1.Icon = Properties.Resources.check;

            }
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox2.Text))
            {
                this.Focus();
                errorProvider2.Icon = Properties.Resources.error;
                errorProvider2.SetError(this.textBox2, "Enter your  Name please!");

            }
            else
            {
                errorProvider2.Icon = Properties.Resources.check;

            }
        }

        private void textBox3_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox3.Text))
            {
                this.Focus();
                errorProvider3.Icon = Properties.Resources.error;
                errorProvider3.SetError(this.textBox3, "Enter your  Contact please!");

            }
            else
            {
                errorProvider3.Icon = Properties.Resources.check;

            }
        }

        private void textBox4_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox4.Text))
            {
                this.Focus();
                errorProvider4.Icon = Properties.Resources.error;
                errorProvider4.SetError(this.textBox4, "Enter your  Email please!");

            }
            else
            {
                errorProvider4.Icon = Properties.Resources.check;

            }
        }

        private void textBox5_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox5.Text))
            {
                this.Focus();
                errorProvider5.Icon = Properties.Resources.error;
                errorProvider5.SetError(this.textBox5, "Enter your  Password please!");

            }
            else
            {
                errorProvider5.Icon = Properties.Resources.check;

            }
        }

        private void textBox6_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox6.Text))
            {
                this.Focus();
                errorProvider6.Icon = Properties.Resources.error;
                errorProvider6.SetError(this.textBox6, "Confirm your  Password please!");

            }
            else
            {
                errorProvider6.Icon = Properties.Resources.check;

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "" && textBox6.Text != "" ) 
            {
                string query = "insert into Reg ([Id],[Name],[Contact],[Email],[Password],[Confirm Password],[Gender]) Values (@id,@name,@contact,@email,@pass,@confirmPass,@gender)";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                cmd.Parameters.AddWithValue("@id", textBox1.Text);
                cmd.Parameters.AddWithValue("@name", textBox2.Text);
                cmd.Parameters.AddWithValue("@contact", textBox3.Text);
                cmd.Parameters.AddWithValue("@email", textBox4.Text);

                cmd.Parameters.AddWithValue("@pass", textBox5.Text);
                cmd.Parameters.AddWithValue("@confirmPass ", textBox6.Text);
                cmd.Parameters.AddWithValue("@gender", getradio());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Your Registration Complete", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Hide();
                new Login().Show();
            }
            else
            {
                MessageBox.Show("Registration Failed", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

            private void button1_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(button1.Text))
            {
                this.Focus();
                errorProvider7.Icon = Properties.Resources.error;
                errorProvider7.SetError(this.button1, "Fill up the form");

            }
            else
            {
                errorProvider7.Icon = Properties.Resources.check;

            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            {
                bool status = checkBox1.Checked;
                switch (status)
                {
                    case true:
                        textBox6.UseSystemPasswordChar = false;
                        break;
                    default:
                        textBox6.UseSystemPasswordChar = true;
                        break;


                }
            }

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            new Login().Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
} 

