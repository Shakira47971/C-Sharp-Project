﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace parlourProject
{
    public partial class CustomerHome : Form
    {
       
        public CustomerHome()
        {
            InitializeComponent();
            

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }
        private Form currentProfileForm;

        private void ShowProfileForm(Form profileForm)
        {
            if (currentProfileForm != null)
            {
                currentProfileForm.Close();
            }

            currentProfileForm = profileForm;
            profileForm.TopLevel = false;
            profileForm.FormBorderStyle = FormBorderStyle.None;
            profileForm.Dock = DockStyle.Fill;
            panel2.Controls.Add(profileForm);
            panel2.Tag = profileForm;
            profileForm.BringToFront();
            profileForm.Show();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            ShowProfileForm(new Contact());
        }

        private void label5_Click(object sender, EventArgs e)
        {
            ShowProfileForm(new Appointment());
        }

        private void label8_Click(object sender, EventArgs e)
        {
            ShowProfileForm(new Payment());
        
    }

        private void label6_Click(object sender, EventArgs e)
        {
            
            ShowProfileForm(new ServiceCus());
            
        }

        

        private void label7_Click(object sender, EventArgs e)
        {
            ShowProfileForm(new Staff());
        }

        private void label10_Click(object sender, EventArgs e)
        {
            ShowProfileForm(new LogOut());
           
        }
       


        private void label9_Click(object sender, EventArgs e)
        {
            ShowProfileForm(new SelectedServicesForm());

        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            
        }

        private void label11_Click(object sender, EventArgs e)
        {
            ShowProfileForm(new SelectedStaff());

        }

        private void label12_Click(object sender, EventArgs e)
        {
            ShowProfileForm(new Invoice());
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            this.Hide();
           new Login().Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            ShowProfileForm(new About());
        }
    }
}
