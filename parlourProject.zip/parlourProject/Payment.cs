﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace parlourProject
{
    public partial class Payment : Form
    {
        public Payment()
        {
            InitializeComponent();
        }
        private Form currentProfileForm;

        private void ShowProfileForm(Form profileForm)
        {
            if (currentProfileForm != null)
            {
                currentProfileForm.Close();
            }

            currentProfileForm = profileForm;
            profileForm.TopLevel = false;
            profileForm.FormBorderStyle = FormBorderStyle.None;
            profileForm.Dock = DockStyle.Fill;
            panel2.Controls.Add(profileForm);
            panel2.Tag = profileForm;
            profileForm.BringToFront();
            profileForm.Show();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            ShowProfileForm(new Bikash());
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            ShowProfileForm(new CreditCard());
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            ShowProfileForm(new Nogod());
        }
    }
}
